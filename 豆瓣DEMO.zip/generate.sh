# $1: page / component
# $2: name of component
mkdir $1s/$2
touch $1s/$2/$2.js
touch $1s/$2/$2.wxss
touch $1s/$2/$2.wxml
touch $1s/$2/$2.json
