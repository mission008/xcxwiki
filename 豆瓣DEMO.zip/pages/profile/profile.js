var app = getApp()

Page({
  data: {
    title: 'About Me',
    userInfo: {
      nickname: 'iceStone',
      realname: '汪磊',
      wechat: 'WEDN-NET',
      avatar: '../../images/wechat.jpeg'
    }
  }
})
