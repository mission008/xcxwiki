Page({
  data: {
    audioAction: {
      method: 'pause'
    }
  },
  audioPlayed: function(e) {
    console.log('audio is played')
  }
})