module.exports = {
    '/album': 'album/routehub',
};
