module.exports = {
    /** 通讯域名 */
    host: 'www.qcloud.la',
    basePath: '/applet/album',
};